
app.controller('landingPageCtrl', ['$scope', function($scope){
	$scope.user = 'Yeshwant Dasari';
}]);
