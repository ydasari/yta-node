app.controller('loginPageCtrl', ['$scope', function($scope){
	$scope.user = 'Yeshwant Dasari';
}]);
